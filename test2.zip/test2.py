import hashlib
import json
import os
import random

import ecdsa
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
from Crypto.Util.number import bytes_to_long, long_to_bytes

IV = os.urandom(8)
KEY = os.urandom(16)
FLAG = os.environ.get("FLAG", "0xL4ugh{6d656f776d6f65776d6f65776d6f6577}").encode()


class Player:
    def __init__(self, credits=0):
        self.credits = credits
        self.dishes_washed = 0


class CoffeShop:
    def __init__(self, available_credits):
        self.available = available_credits
        self.curve = ecdsa.curves.NIST224p
        self.g = self.curve.generator
        self.d = random.randint(1, self.curve.order - 1)  # Private key (which we can't easily get)
        self.pubkey = ecdsa.ecdsa.Public_key(self.g, self.g * self.d)
        self.privkey = ecdsa.ecdsa.Private_key(self.pubkey, self.d)
        self.branch_location = (
            int(self.pubkey.point.x()), int(self.pubkey.point.y())
        )
        self.gen_ks()

    def gen_ks(self):
        c = [random.randint(1, self.curve.order - 1) for _ in range(6)]
        self.ks = [random.randint(1, self.curve.order - 1)]
        for i in range(7):
            k = int(sum((c[j] * (self.ks[i] ** j)) %
                    self.curve.order for j in range(6)) % self.curve.order)
            self.ks.append(k)

    def pay_player(self, player):
        credit = "100 EGP"
        sha256 = hashlib.sha256()
        sha256.update(credit.encode())
        hash = bytes_to_long(sha256.digest()) % self.curve.order
        player.credits += 100
        self.available -= 100
        coin = self.privkey.sign(hash, self.ks.pop())
        return json.dumps({"s": int(coin.s), "r": int(coin.r)})

    def clean(self, data):
        plate = data.encode()
        cipher = AES.new(KEY, AES.MODE_CTR, nonce=IV)
        return cipher.encrypt(plate).hex()

    def check_if_clean(self, data, plate):
        cipher = AES.new(KEY, AES.MODE_CTR, nonce=IV)
        try:
            p = json.loads(cipher.decrypt(bytes.fromhex(data)).decode())
            m = json.loads(plate)
            if p["plate_no"] == m["plate_no"] and p["plate_prop"] == m["plate_prop"]:
                return True
        except BaseException:
            pass
        return False

    def wash_dishes(self, player):
        if shop.available < 100:
            return "We're out of money, sorry :c"
        plate_no = f"{player.dishes_washed}"
        plate_prop = random.randint(1, 9)
        plate = json.dumps({"plate_no": plate_no, "plate_prop": plate_prop})
        print(f"Please clean the following plate: {plate}")
        cleaned = input("(hex) > ")
        if self.check_if_clean(cleaned, plate):
            player.dishes_washed += 1
            print("Here's your cheque: ", end="")
            print(self.pay_player(player))
            return "Good job! You got 100 EGP."
        return "You didn't clean the plate properly! >:c"

    def checkout(self, player):
        if player.credits >= 800:
            print("You have enough money to pay for the meal! c:")
            sha256 = hashlib.sha256()
            sha256.update(long_to_bytes(self.d))
            key = sha256.digest()
            iv = os.urandom(16)
            cipher = AES.new(key, AES.MODE_CBC, iv)
            print(f"Here's your receipt: ")
            return iv.hex() + cipher.encrypt(pad(FLAG, 16)).hex()
        return "You don't have enough money to pay for the meal! >:c"


# Initialize the game environment
shop = CoffeShop(800)
you = Player(0)

# Simulate the player washing dishes and accumulating credits
you.credits = 800  # Directly set the credits to 800 (bypassing the cleaning process)

# Now, directly call the checkout method to get the encrypted flag
print(shop.checkout(you))
